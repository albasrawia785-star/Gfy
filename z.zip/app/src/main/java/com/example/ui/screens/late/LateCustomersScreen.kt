package com.example.ui.screens.late

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Send
import com.example.util.formatDateOnly
import com.example.util.sendWhatsAppReminder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.BabyConfig
import com.example.data.model.Customer
import com.example.data.model.LateCustomer
import com.example.data.model.OperationType
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SurfaceLight
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.util.formatCurrency
import com.example.util.formatWithCommas
import com.example.util.formatDateTime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LateCustomersScreen(
    viewModel: LateCustomersViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lateCustomers by viewModel.lateCustomers.collectAsStateWithLifecycle()

    var customerForOperation by remember { mutableStateOf<Pair<Customer, OperationType>?>(null) }

    LaunchedEffect(Unit) {
        viewModel.uiEvent.collect { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        containerColor = SurfaceLight,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Header Title
            Text(
                text = "المدينون المتأخرون",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryDark,
                    fontSize = 20.sp
                ),
                modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)
            )

            if (lateCustomers.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            modifier = Modifier.size(72.dp),
                            tint = EmeraldGreen.copy(alpha = 0.7f)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "لا يوجد مدينون متأخرون.",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = TextPrimaryDark
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "جميع المدينين ملتزمون بالسداد أو ضمن الفترة المحددة",
                            fontSize = 13.sp,
                            color = TextSecondaryDark
                        )
                    }
                }
            } else {
                Surface(
                    color = CrimsonRed.copy(alpha = 0.08f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.HourglassTop,
                            contentDescription = null,
                            tint = CrimsonRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إجمالي المدينين المتأخرين عن السداد: ${lateCustomers.size} مدين",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = CrimsonRed
                        )
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(lateCustomers, key = { it.customer.id }) { item ->
                        LateCustomerCard(
                            item = item,
                            onAddDebt = { customerForOperation = Pair(item.customer, OperationType.DEBT) },
                            onAddPayment = { customerForOperation = Pair(item.customer, OperationType.PAYMENT) },
                            onCall = { phone ->
                                try {
                                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "تعذر إجراء الاتصال", Toast.LENGTH_SHORT).show()
                                }
                            }
                        )
                    }
                    item { Spacer(modifier = Modifier.height(16.dp)) }
                }
            }
        }
    }

    // Operation Dialog
    customerForOperation?.let { (customer, type) ->
        LateOperationDialog(
            customer = customer,
            type = type,
            onDismiss = { customerForOperation = null },
            onSave = { amount, note, onSuccess, onError ->
                viewModel.addOperation(
                    customerId = customer.id,
                    type = type,
                    amount = amount,
                    note = note,
                    onSuccess = {
                        customerForOperation = null
                        onSuccess()
                    },
                    onError = onError
                )
            }
        )
    }
}

@Composable
fun LateCustomerCard(
    item: LateCustomer,
    onAddDebt: () -> Unit,
    onAddPayment: () -> Unit,
    onCall: (String) -> Unit
) {
    val cust = item.customer
    val context = LocalContext.current

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Customer Name & Overdue Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = Color(0xFFFEE2E2),
                        shape = CircleShape,
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = CrimsonRed,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = cust.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = TextPrimaryDark
                        )
                        cust.phone?.let { phoneNum ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.clip(RoundedCornerShape(4.dp))
                            ) {
                                Text(
                                    text = phoneNum,
                                    fontSize = 12.sp,
                                    color = RoyalBlue,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                Surface(
                    color = CrimsonRed,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = "متأخر منذ ${item.daysOverdue} يوم",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Debt details row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceLight, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("إجمالي الدين المتبقي", fontSize = 11.sp, color = TextSecondaryDark)
                    Text(
                        text = cust.debtAmount.formatCurrency(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = CrimsonRed
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("تاريخ آخر دين جديد", fontSize = 11.sp, color = TextSecondaryDark)
                    Text(
                        text = item.lastDebtDate.formatDateTime(),
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp,
                        color = TextPrimaryDark
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons: New Debt & Payment
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (!cust.phone.isNullOrBlank()) {
                    IconButton(
                        onClick = { onCall(cust.phone) },
                        modifier = Modifier
                            .background(RoyalBlue.copy(alpha = 0.1f), RoundedCornerShape(10.dp))
                            .size(42.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Phone, contentDescription = "اتصال", tint = RoyalBlue)
                    }

                    IconButton(
                        onClick = {
                            sendWhatsAppReminder(
                                context = context,
                                phone = cust.phone,
                                customerName = cust.name,
                                debtAmount = cust.debtAmount,
                                dueDate = item.lastDebtDate.formatDateOnly()
                            )
                        },
                        modifier = Modifier
                            .background(Color(0xFFDCFCE7), RoundedCornerShape(10.dp))
                            .size(42.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Send, contentDescription = "واتساب", tint = Color(0xFF059669))
                    }
                }

                Button(
                    onClick = onAddDebt,
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f).height(42.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("دين جديد", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onAddPayment,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f).height(42.dp)
                ) {
                    Icon(imageVector = Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تسديد", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun LateOperationDialog(
    customer: Customer,
    type: OperationType,
    onDismiss: () -> Unit,
    onSave: (amount: Long, note: String, onSuccess: () -> Unit, onError: (String) -> Unit) -> Unit
) {
    var amountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    val isDebt = type == OperationType.DEBT
    val titleStr = if (isDebt) "دين جديد" else "تسديد دين"

    Dialog(onDismissRequest = { if (!isLoading) onDismiss() }) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = titleStr,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                    )
                    IconButton(onClick = onDismiss, enabled = !isLoading) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "إغلاق",
                            tint = if (isLoading) BorderLight else TextSecondaryDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (errorText != null) {
                    Surface(
                        color = Color(0xFFFEE2E2),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Error, contentDescription = null, tint = CrimsonRed, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = errorText!!, color = CrimsonRed, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }

                Text("المدين", fontWeight = FontWeight.Medium, fontSize = 13.sp, color = TextSecondaryDark)
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                    color = SurfaceLight,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = TextSecondaryDark,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = customer.name,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("المبلغ", fontWeight = FontWeight.Medium, fontSize = 13.sp, color = TextSecondaryDark)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { input ->
                        val cleanDigits = input.replace(",", "").filter { it.isDigit() }
                        if (cleanDigits.isEmpty()) {
                            amountText = ""
                            errorText = null
                        } else if (cleanDigits.length <= 15) {
                            cleanDigits.toLongOrNull()?.let { number ->
                                amountText = number.formatWithCommas()
                                errorText = null
                            }
                        }
                    },
                    enabled = !isLoading,
                    placeholder = { Text("0", color = TextSecondaryDark) },
                    leadingIcon = {
                        Text(
                            text = BabyConfig.CURRENCY,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondaryDark,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    isError = errorText != null,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RoyalBlue,
                        unfocusedBorderColor = BorderLight
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("ملاحظات (اختياري)", fontWeight = FontWeight.Medium, fontSize = 13.sp, color = TextSecondaryDark)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    enabled = !isLoading,
                    placeholder = { Text("اكتب ملاحظة...", color = TextSecondaryDark) },
                    leadingIcon = { Icon(Icons.Default.EditNote, contentDescription = null, tint = TextSecondaryDark) },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RoyalBlue,
                        unfocusedBorderColor = BorderLight
                    )
                )

                Spacer(modifier = Modifier.height(20.dp))

                val parsedAmount = amountText.replace(",", "").toLongOrNull() ?: 0L

                Button(
                    onClick = {
                        if (isLoading) return@Button
                        if (type == OperationType.PAYMENT && parsedAmount > customer.debtAmount) {
                            errorText = "المبلغ المراد تسديده أكبر من الدين الحالي"
                        } else {
                            isLoading = true
                            errorText = null
                            onSave(
                                parsedAmount,
                                note,
                                {
                                    isLoading = false
                                    onDismiss()
                                },
                                { err ->
                                    isLoading = false
                                    errorText = err
                                }
                            )
                        }
                    },
                    enabled = parsedAmount > 0 && !isLoading,
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("جاري الحفظ...", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    } else {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("حفظ العملية", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
        }
    }
}
