package com.example.ui.screens.login

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.sin

/**
 * Modern 3D AI Assistant Robot Mascot for Debt Management App.
 *
 * Interactive Behaviors:
 * 1. Entrance: Drops down from top with gentle bounce, stands above input fields, waves & smiles.
 * 2. Username Focus: Descends down, leans forward, places right hand on top edge of username input field, tracks cursor with eyes.
 * 3. Password Focus: Ascends to original position at top, raises both hands and covers eyes completely.
 * 4. Password Toggle: Uncovers eyes, smiles, looks at user.
 * 5. Success Login: Thumbs-up gesture, green ✓ appears, exits upwards.
 * 6. Failed Login: Puzzled head shake, returns to idle waiting pose.
 */
@Composable
fun InteractiveMascotCharacter(
    isUsernameFocused: Boolean,
    usernameLength: Int,
    isPasswordFocused: Boolean,
    isPasswordVisible: Boolean,
    isLoading: Boolean,
    isSuccess: Boolean,
    isError: Boolean,
    modifier: Modifier = Modifier,
    characterSize: Dp = 190.dp
) {
    // 1. Entrance drop-down from top with gentle bounce
    val entranceAnimatable = remember { Animatable(-180f) }
    val waveAnimatable = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        // Drop down from top
        entranceAnimatable.animateTo(
            targetValue = 0f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessLow
            )
        )
        // Friendly wave greeting
        repeat(3) {
            waveAnimatable.animateTo(1f, animationSpec = tween(350, easing = FastOutSlowInEasing))
            waveAnimatable.animateTo(-0.4f, animationSpec = tween(350, easing = FastOutSlowInEasing))
        }
        waveAnimatable.animateTo(0f, animationSpec = tween(280))
    }

    // 2. Exit upwards animation on login success
    val exitAnimatable = remember { Animatable(0f) }
    LaunchedEffect(isSuccess) {
        if (isSuccess) {
            kotlinx.coroutines.delay(700)
            exitAnimatable.animateTo(
                targetValue = -320f,
                animationSpec = tween(550, easing = FastOutSlowInEasing)
            )
        }
    }

    // Head shake on error
    val shakeAnimatable = remember { Animatable(0f) }
    LaunchedEffect(isError) {
        if (isError) {
            repeat(4) {
                shakeAnimatable.animateTo(12f, animationSpec = tween(45))
                shakeAnimatable.animateTo(-12f, animationSpec = tween(45))
            }
            shakeAnimatable.animateTo(0f, animationSpec = spring(stiffness = Spring.StiffnessMedium))
        }
    }

    // Celebration jump on success
    val jumpAnimatable = remember { Animatable(0f) }
    LaunchedEffect(isSuccess) {
        if (isSuccess) {
            jumpAnimatable.animateTo(-24f, animationSpec = tween(200, easing = FastOutSlowInEasing))
            jumpAnimatable.animateTo(0f, animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy))
        }
    }

    // Infinite ambient floating motion
    val infiniteTransition = rememberInfiniteTransition(label = "robot_idle")
    val idleFloatY by infiniteTransition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "idle_float"
    )

    val headTilt by infiniteTransition.animateFloat(
        initialValue = -3f,
        targetValue = 3f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "head_tilt"
    )

    // Descend down progress when username field is focused
    val descendProgress by animateFloatAsState(
        targetValue = if (isUsernameFocused && !isPasswordFocused) 1f else 0f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioLowBouncy),
        label = "descend_prog"
    )

    // Cover eyes progress when password field is focused and password NOT visible
    val coverEyesProgress by animateFloatAsState(
        targetValue = if (isPasswordFocused && !isPasswordVisible) 1f else 0f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioLowBouncy),
        label = "cover_eyes_prog"
    )

    // Pupil cursor tracking positions
    val targetPupilX = when {
        isUsernameFocused -> ((usernameLength * 1.5f).coerceIn(0f, 22f) - 11f)
        else -> 0f
    }
    val pupilX by animateFloatAsState(
        targetValue = targetPupilX,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "pupil_x_prog"
    )

    val targetPupilY = when {
        isUsernameFocused -> 10f // Look directly down at username field
        isPasswordFocused -> -2f
        else -> 0f
    }
    val pupilY by animateFloatAsState(
        targetValue = targetPupilY,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "pupil_y_prog"
    )

    val waveOffset = waveAnimatable.value
    val shakeOffset = shakeAnimatable.value
    val jumpOffset = jumpAnimatable.value
    val dropY = entranceAnimatable.value + exitAnimatable.value

    // Downward translation when focusing username field
    val verticalTranslationY = descendProgress * 46f

    Box(
        modifier = modifier
            .size(characterSize)
            .graphicsLayer {
                translationX = shakeOffset
                translationY = dropY + idleFloatY + jumpOffset + verticalTranslationY
                rotationZ = if (isLoading) headTilt * 2.5f else (headTilt + descendProgress * 2f)
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val centerX = w / 2f
            val centerY = h / 2f

            // Futuristic Soft Ambient Floor Shadow
            drawOval(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x252563EB), Color.Transparent),
                    center = Offset(centerX, h * 0.90f),
                    radius = w * 0.38f
                ),
                topLeft = Offset(centerX - w * 0.35f, h * 0.85f),
                size = Size(w * 0.70f, h * 0.12f)
            )

            // --- 1. SLEEK FLOATING BODY / CHEST ---
            val bodyWidth = w * 0.44f
            val bodyHeight = h * 0.34f
            val bodyTop = centerY + h * 0.08f

            // Glossy White Ceramic Body
            val bodyGradient = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFFFFFFFF),
                    Color(0xFFF1F5F9),
                    Color(0xFFE2E8F0)
                ),
                startY = bodyTop,
                endY = bodyTop + bodyHeight
            )

            drawRoundRect(
                brush = bodyGradient,
                topLeft = Offset(centerX - bodyWidth / 2f, bodyTop),
                size = Size(bodyWidth, bodyHeight),
                cornerRadius = CornerRadius(24f, 24f)
            )

            // Body Outer Bezel
            drawRoundRect(
                color = Color(0x30CBD5E1),
                topLeft = Offset(centerX - bodyWidth / 2f, bodyTop),
                size = Size(bodyWidth, bodyHeight),
                cornerRadius = CornerRadius(24f, 24f),
                style = Stroke(width = 2.5f)
            )

            // Glowing Core Orb (Fintech Blue / Purple Heart)
            val coreColor = if (isSuccess) Color(0xFF10B981) else Color(0xFF2563EB)
            val coreGlow = Brush.radialGradient(
                colors = listOf(
                    coreColor,
                    Color(0xFF7C3AED).copy(alpha = 0.6f),
                    Color.Transparent
                ),
                center = Offset(centerX, bodyTop + bodyHeight * 0.42f),
                radius = 28f
            )
            drawCircle(brush = coreGlow, radius = 22f, center = Offset(centerX, bodyTop + bodyHeight * 0.42f))
            drawCircle(color = Color.White, radius = 7f, center = Offset(centerX - 2f, bodyTop + bodyHeight * 0.42f - 2f))

            // --- 2. HEAD ASSEMBLY (3D Helmet & Visor Screen) ---
            val headWidth = w * 0.62f
            val headHeight = h * 0.46f
            val headTop = centerY - h * 0.36f

            // Head Outer Ceramic Shell
            val headShellGradient = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFFFFFFFF),
                    Color(0xFFF8FAFC),
                    Color(0xFFCBD5E1)
                ),
                startY = headTop,
                endY = headTop + headHeight
            )

            drawRoundRect(
                brush = headShellGradient,
                topLeft = Offset(centerX - headWidth / 2f, headTop),
                size = Size(headWidth, headHeight),
                cornerRadius = CornerRadius(44f, 44f)
            )

            // Head Shell Bezel Line
            drawRoundRect(
                color = Color(0x4094A3B8),
                topLeft = Offset(centerX - headWidth / 2f, headTop),
                size = Size(headWidth, headHeight),
                cornerRadius = CornerRadius(44f, 44f),
                style = Stroke(width = 2.5f)
            )

            // Side Ears / Tech Nodes
            val earWidth = 14f
            val earHeight = 32f
            val earY = headTop + headHeight * 0.36f

            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color(0xFF2563EB), Color(0xFF7C3AED))),
                topLeft = Offset(centerX - headWidth / 2f - earWidth + 3f, earY),
                size = Size(earWidth, earHeight),
                cornerRadius = CornerRadius(8f, 8f)
            )
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color(0xFF2563EB), Color(0xFF7C3AED))),
                topLeft = Offset(centerX + headWidth / 2f - 3f, earY),
                size = Size(earWidth, earHeight),
                cornerRadius = CornerRadius(8f, 8f)
            )

            // --- 3. DARK GLOSSY GLASS VISOR ---
            val visorWidth = headWidth * 0.82f
            val visorHeight = headHeight * 0.64f
            val visorTop = headTop + (headHeight - visorHeight) / 2f

            val visorGradient = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF0F172A),
                    Color(0xFF1E1B4B),
                    Color(0xFF0F172A)
                ),
                startY = visorTop,
                endY = visorTop + visorHeight
            )

            drawRoundRect(
                brush = visorGradient,
                topLeft = Offset(centerX - visorWidth / 2f, visorTop),
                size = Size(visorWidth, visorHeight),
                cornerRadius = CornerRadius(30f, 30f)
            )

            // Glass Highlight Reflection
            val visorPath = Path().apply {
                moveTo(centerX - visorWidth * 0.38f, visorTop + 6f)
                quadraticTo(
                    centerX, visorTop + 16f,
                    centerX + visorWidth * 0.38f, visorTop + 6f
                )
            }
            drawPath(
                path = visorPath,
                color = Color.White.copy(alpha = 0.25f),
                style = Stroke(width = 3f, cap = StrokeCap.Round)
            )

            // --- 4. GLOWING LED EYES & EXPRESSIONS ---
            val eyeSpacing = visorWidth * 0.28f
            val eyeY = visorTop + visorHeight * 0.44f
            val leftEyeX = centerX - eyeSpacing
            val rightEyeX = centerX + eyeSpacing

            val ledColor = when {
                isSuccess -> Color(0xFF10B981) // Cyan Emerald Green
                isError -> Color(0xFFEF4444)   // Crimson Alert
                else -> Color(0xFF38BDF8)     // Modern Cyan LED
            }

            if (isSuccess) {
                // Happy LED Curves (^ ^)
                val leftCurve = Path().apply {
                    moveTo(leftEyeX - 12f, eyeY + 4f)
                    quadraticTo(leftEyeX, eyeY - 12f, leftEyeX + 12f, eyeY + 4f)
                }
                val rightCurve = Path().apply {
                    moveTo(rightEyeX - 12f, eyeY + 4f)
                    quadraticTo(rightEyeX, eyeY - 12f, rightEyeX + 12f, eyeY + 4f)
                }

                drawPath(leftCurve, color = ledColor, style = Stroke(width = 6f, cap = StrokeCap.Round))
                drawPath(rightCurve, color = ledColor, style = Stroke(width = 6f, cap = StrokeCap.Round))

                // Smile on Visor
                val smilePath = Path().apply {
                    moveTo(centerX - 12f, visorTop + visorHeight * 0.72f)
                    quadraticTo(centerX, visorTop + visorHeight * 0.86f, centerX + 12f, visorTop + visorHeight * 0.72f)
                }
                drawPath(smilePath, color = ledColor, style = Stroke(width = 4f, cap = StrokeCap.Round))
            } else if (coverEyesProgress < 0.85f) {
                // Active Glowing LED Oval Eyes with Cursor Pupil Tracking
                val eyeRadiusX = 14f
                val eyeRadiusY = if (isPasswordVisible) 18f else 15f

                val curPupilX = pupilX
                val curPupilY = pupilY

                // Left Eye Glow & Core
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(ledColor, ledColor.copy(alpha = 0.2f), Color.Transparent),
                        center = Offset(leftEyeX + curPupilX, eyeY + curPupilY),
                        radius = 24f
                    ),
                    radius = 22f,
                    center = Offset(leftEyeX + curPupilX, eyeY + curPupilY)
                )
                drawRoundRect(
                    color = Color.White,
                    topLeft = Offset(leftEyeX + curPupilX - eyeRadiusX / 2f, eyeY + curPupilY - eyeRadiusY / 2f),
                    size = Size(eyeRadiusX, eyeRadiusY),
                    cornerRadius = CornerRadius(8f, 8f)
                )

                // Right Eye Glow & Core
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(ledColor, ledColor.copy(alpha = 0.2f), Color.Transparent),
                        center = Offset(rightEyeX + curPupilX, eyeY + curPupilY),
                        radius = 24f
                    ),
                    radius = 22f,
                    center = Offset(rightEyeX + curPupilX, eyeY + curPupilY)
                )
                drawRoundRect(
                    color = Color.White,
                    topLeft = Offset(rightEyeX + curPupilX - eyeRadiusX / 2f, eyeY + curPupilY - eyeRadiusY / 2f),
                    size = Size(eyeRadiusX, eyeRadiusY),
                    cornerRadius = CornerRadius(8f, 8f)
                )

                // Mouth Indicator
                if (isError) {
                    val errorMouth = Path().apply {
                        moveTo(centerX - 12f, visorTop + visorHeight * 0.76f)
                        lineTo(centerX - 4f, visorTop + visorHeight * 0.72f)
                        lineTo(centerX + 4f, visorTop + visorHeight * 0.78f)
                        lineTo(centerX + 12f, visorTop + visorHeight * 0.74f)
                    }
                    drawPath(errorMouth, color = ledColor, style = Stroke(width = 3.5f, cap = StrokeCap.Round))
                } else if (isPasswordVisible) {
                    val happyMouth = Path().apply {
                        moveTo(centerX - 12f, visorTop + visorHeight * 0.72f)
                        quadraticTo(centerX, visorTop + visorHeight * 0.86f, centerX + 12f, visorTop + visorHeight * 0.72f)
                    }
                    drawPath(happyMouth, color = ledColor, style = Stroke(width = 4f, cap = StrokeCap.Round))
                } else if (descendProgress > 0.5f) {
                    drawCircle(color = ledColor, radius = 4f, center = Offset(centerX, visorTop + visorHeight * 0.78f))
                } else {
                    drawCircle(color = ledColor.copy(alpha = 0.9f), radius = 3.5f, center = Offset(centerX, visorTop + visorHeight * 0.76f))
                }
            } else {
                // Closed Eyes LED Line on Visor
                val closedLineLeft = Path().apply {
                    moveTo(leftEyeX - 10f, eyeY)
                    lineTo(leftEyeX + 10f, eyeY)
                }
                val closedLineRight = Path().apply {
                    moveTo(rightEyeX - 10f, eyeY)
                    lineTo(rightEyeX + 10f, eyeY)
                }
                drawPath(closedLineLeft, color = ledColor.copy(alpha = 0.8f), style = Stroke(width = 3.5f, cap = StrokeCap.Round))
                drawPath(closedLineRight, color = ledColor.copy(alpha = 0.8f), style = Stroke(width = 3.5f, cap = StrokeCap.Round))
            }

            // --- 5. ROBOT ARMS & PAWS (POSING LOGIC) ---
            val armRadius = 18f

            // Default Resting Paws
            val defaultLeftPawX = centerX - headWidth * 0.52f
            val defaultLeftPawY = centerY + h * 0.18f

            val defaultRightPawX = centerX + headWidth * 0.52f
            val defaultRightPawY = centerY + h * 0.18f

            // Password Cover Eyes Targets
            val coverLeftPawX = leftEyeX + 6f
            val coverLeftPawY = eyeY + 4f

            val coverRightPawX = rightEyeX - 6f
            val coverRightPawY = eyeY + 4f

            // Username Focus Targets (Placing hand on top edge of username input field)
            val reachRightPawX = centerX + headWidth * 0.35f
            val reachRightPawY = h * 0.92f

            // Waving Paw Calculations
            val waveY = if (waveOffset != 0f) -sin(waveOffset * Math.PI.toFloat()) * 32f else 0f
            val waveX = waveOffset * 18f

            // Compute Paw Positions:
            val targetLeftPawX = defaultLeftPawX + (coverLeftPawX - defaultLeftPawX) * coverEyesProgress
            val targetLeftPawY = defaultLeftPawY + (coverLeftPawY - defaultLeftPawY) * coverEyesProgress

            val targetRightPawX = when {
                coverEyesProgress > 0.1f -> (defaultRightPawX + waveX) + (coverRightPawX - (defaultRightPawX + waveX)) * coverEyesProgress
                descendProgress > 0.1f -> defaultRightPawX + (reachRightPawX - defaultRightPawX) * descendProgress
                else -> defaultRightPawX + waveX
            }

            val targetRightPawY = when {
                coverEyesProgress > 0.1f -> (defaultRightPawY + waveY) + (coverRightPawY - (defaultRightPawY + waveY)) * coverEyesProgress
                descendProgress > 0.1f -> defaultRightPawY + (reachRightPawY - defaultRightPawY) * descendProgress
                else -> defaultRightPawY + waveY
            }

            // Left Robotic Paw Capsule
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White, Color(0xFFCBD5E1)),
                    center = Offset(targetLeftPawX, targetLeftPawY),
                    radius = armRadius
                ),
                radius = armRadius,
                center = Offset(targetLeftPawX, targetLeftPawY)
            )
            drawCircle(color = Color(0xFF2563EB), radius = 6f, center = Offset(targetLeftPawX, targetLeftPawY))

            // Right Robotic Paw Capsule
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White, Color(0xFFCBD5E1)),
                    center = Offset(targetRightPawX, targetRightPawY),
                    radius = armRadius
                ),
                radius = armRadius,
                center = Offset(targetRightPawX, targetRightPawY)
            )
            drawCircle(color = Color(0xFF2563EB), radius = 6f, center = Offset(targetRightPawX, targetRightPawY))

            // --- 6. SUCCESS CHECKMARK BADGE ---
            if (isSuccess) {
                val checkCenterX = centerX + headWidth * 0.45f
                val checkCenterY = headTop + 10f

                drawCircle(color = Color(0xFF10B981), radius = 22f, center = Offset(checkCenterX, checkCenterY))

                val checkPath = Path().apply {
                    moveTo(checkCenterX - 10f, checkCenterY)
                    lineTo(checkCenterX - 2f, checkCenterY + 8f)
                    lineTo(checkCenterX + 10f, checkCenterY - 8f)
                }
                drawPath(checkPath, color = Color.White, style = Stroke(width = 5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}
