package com.example.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.AldionFirebaseManager
import com.example.data.model.Manager
import com.example.data.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val firebaseManager: AldionFirebaseManager = AldionFirebaseManager()
) : ViewModel() {

    val overdueDaysThreshold: StateFlow<Int> = settingsRepository.overdueDays
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 30
        )

    val managers: StateFlow<List<Manager>> = firebaseManager.getManagersFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _uiEvent = MutableSharedFlow<String>()
    val uiEvent: SharedFlow<String> = _uiEvent.asSharedFlow()

    fun logout(onComplete: () -> Unit) {
        viewModelScope.launch {
            settingsRepository.setLoggedIn(false)
            onComplete()
        }
    }

    fun updateOverdueDaysThreshold(days: Int) {
        viewModelScope.launch {
            if (days > 0) {
                settingsRepository.saveOverdueDays(days)
                _uiEvent.emit("تم حفظ عدد أيام التأخير: $days يوم")
            } else {
                _uiEvent.emit("يرجى إدخال عدد أيام صحيح (أكبر من 0)")
            }
        }
    }

    fun addManager(
        shopName: String,
        managerName: String,
        username: String,
        password: String,
        phone: String,
        status: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val cleanShop = shopName.trim()
            val cleanUser = username.trim()
            val cleanPass = password.trim()
            val cleanPhone = phone.trim()

            if (cleanShop.isEmpty() || cleanUser.isEmpty() || cleanPass.isEmpty()) {
                onError("جميع الحقول المطلوبة يجب إدخالها")
                return@launch
            }

            val timestamp = System.currentTimeMillis()
            val newManager = Manager(
                managerId = "mgr_$timestamp",
                shopId = "shop_$timestamp",
                shopName = cleanShop,
                username = cleanUser,
                password = cleanPass,
                phone = cleanPhone,
                role = "ADMIN",
                status = status,
                createdAt = timestamp,
                lastLogin = 0L
            )

            val res = firebaseManager.saveManager(newManager)
            if (res.isSuccess) {
                _uiEvent.emit("تم إضافة المدير بنجاح")
                onSuccess()
            } else {
                val err = res.exceptionOrNull()?.message ?: "حدث خطأ أثناء حفظ المدير"
                onError(err)
            }
        }
    }

    fun updateManager(
        managerId: String,
        shopName: String,
        username: String,
        phone: String,
        status: String,
        role: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val res = firebaseManager.updateManagerData(
                managerId = managerId,
                shopName = shopName,
                username = username,
                phone = phone,
                status = status,
                role = role
            )
            if (res.isSuccess) {
                _uiEvent.emit("تم تحديث بيانات المدير بنجاح")
                onSuccess()
            } else {
                val err = res.exceptionOrNull()?.message ?: "حدث خطأ أثناء تحديث المدير"
                onError(err)
            }
        }
    }

    fun changePassword(
        managerId: String,
        newPass: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            if (newPass.trim().isBlank()) {
                onError("يرجى إدخال كلمة مرور جديدة صحيحة")
                return@launch
            }
            val res = firebaseManager.updateManagerPassword(managerId, newPass.trim())
            if (res.isSuccess) {
                _uiEvent.emit("تم تغيير كلمة المرور بنجاح")
                onSuccess()
            } else {
                val err = res.exceptionOrNull()?.message ?: "حدث خطأ أثناء تغيير كلمة المرور"
                onError(err)
            }
        }
    }

    fun toggleManagerStatus(
        manager: Manager,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val newStatus = if (manager.isActive()) "DISABLED" else "ACTIVE"
            val res = firebaseManager.updateManagerData(
                managerId = manager.managerId,
                status = newStatus
            )
            if (res.isSuccess) {
                val msg = if (newStatus == "ACTIVE") "تم إعادة تفعيل المدير بنجاح" else "تم تعطيل المدير بنجاح"
                _uiEvent.emit(msg)
                onSuccess()
            } else {
                onError("فشل تغيير حالة المدير")
            }
        }
    }

    fun deleteManager(
        managerId: String,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val res = firebaseManager.deleteManager(managerId)
            if (res.isSuccess) {
                _uiEvent.emit("تم حذف المدير بنجاح")
                onSuccess()
            } else {
                val err = res.exceptionOrNull()?.message ?: "حدث خطأ أثناء حذف المدير"
                onError(err)
            }
        }
    }

    class Factory(
        private val settingsRepository: SettingsRepository,
        private val firebaseManager: AldionFirebaseManager = AldionFirebaseManager()
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SettingsViewModel(settingsRepository, firebaseManager) as T
        }
    }
}
