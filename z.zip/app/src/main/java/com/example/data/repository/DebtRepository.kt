package com.example.data.repository

import android.util.Log
import androidx.room.withTransaction
import com.example.AldionFirebaseManager
import com.example.data.local.AppDatabase
import com.example.data.model.Customer
import com.example.data.model.Operation
import com.example.data.model.OperationType
import com.example.data.model.OperationWithCustomer
import com.example.util.formatCurrency
import kotlinx.coroutines.flow.Flow

data class AddOperationResult(
    val operationId: Long,
    val isZeroDebtReached: Boolean,
    val updatedCustomer: Customer,
    val operation: Operation
)

class DebtRepository(
    private val database: AppDatabase,
    private val firebaseManager: AldionFirebaseManager = AldionFirebaseManager()
) {
    private val customerDao = database.customerDao()
    private val operationDao = database.operationDao()

    val allCustomers: Flow<List<Customer>> = customerDao.getAllCustomers()
    val totalDebtSum: Flow<Long?> = customerDao.getTotalDebtSum()
    val customerCount: Flow<Int> = customerDao.getCustomerCount()
    val totalDebtAddedSum: Flow<Long?> = operationDao.getTotalDebtAddedSum()
    val totalPaymentsSum: Flow<Long?> = operationDao.getTotalPaymentsSum()
    val allOperationsWithCustomer: Flow<List<OperationWithCustomer>> = operationDao.getAllOperationsWithCustomer()

    fun getOperationsForCustomer(customerId: Long): Flow<List<Operation>> {
        return operationDao.getOperationsForCustomer(customerId)
    }

    fun searchCustomers(query: String): Flow<List<Customer>> {
        return if (query.isBlank()) {
            customerDao.getAllCustomers()
        } else {
            customerDao.searchCustomersByName(query.trim())
        }
    }

    suspend fun getCustomerById(id: Long): Customer? = customerDao.getCustomerById(id)

    /**
     * بدء الاستماع المباشر للتغيرات السحابية
     */
    fun startRealtimeSync(scope: kotlinx.coroutines.CoroutineScope) {
        firebaseManager.setupRealtimeListeners(customerDao, operationDao, scope)
    }

    /**
     * مزامنة البيانات السحابية تلقائياً في الخلفية
     */
    suspend fun syncWithCloud() {
        try {
            firebaseManager.syncUnsyncedData(customerDao, operationDao)
        } catch (e: Exception) {
            // Offline or network error handled gracefully
        }
    }

    /**
     * استعادة البيانات السحابية عند تسجيل الدخول أو التطبيق الجديد
     */
    suspend fun restoreCloudData(): Result<Unit> {
        return try {
            firebaseManager.restoreFromCloud(customerDao, operationDao)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addCustomer(name: String, phone: String?, initialDebt: Long): Result<Long> {
        val trimmedName = name.trim()
        Log.d("AldionRepository", ">>> [Step 1] addCustomer initiated in Repository | Name: '$trimmedName', Phone: '$phone', InitialDebt: $initialDebt")

        if (trimmedName.isEmpty()) {
            val err = "اسم المدين مطلوب"
            Log.e("AldionRepository", ">>> [Step 1.1] Validation Failed: $err")
            return Result.failure(IllegalArgumentException(err))
        }

        val currentCount = customerDao.getDirectCustomerCount()
        if (currentCount >= 3) {
            val err = "يجب الاشتراك في النسخة الكاملة لإضافة أكثر من 3 مدينين"
            Log.e("AldionRepository", ">>> [Step 1.2] Subscription Limit Exceeded: $err")
            return Result.failure(IllegalStateException(err))
        }

        val customer = Customer(
            name = trimmedName,
            phone = phone?.trim()?.ifEmpty { null },
            debtAmount = initialDebt.coerceAtLeast(0L),
            isSynced = false
        )

        return try {
            var initialOpToSave: Operation? = null

            val (customerId, createdCustomer) = database.withTransaction {
                val id = customerDao.insertCustomer(customer)
                if (initialDebt > 0L) {
                    val initialOp = Operation(
                        customerId = id,
                        type = OperationType.DEBT,
                        amount = initialDebt,
                        note = "دين أولي",
                        dateTime = System.currentTimeMillis(),
                        isSynced = false
                    )
                    val opId = operationDao.insertOperation(initialOp)
                    initialOpToSave = initialOp.copy(id = opId)
                }
                Pair(id, customer.copy(id = id))
            }

            Log.d("AldionRepository", ">>> [Step 2] Inserted customer locally in Room DB | ID: $customerId. Starting Firestore sync...")

            // Save Customer to Firestore (Wait for real success/failure)
            val customerSyncResult = firebaseManager.saveCustomerSuspend(createdCustomer)
            if (customerSyncResult.isFailure) {
                val syncErr = customerSyncResult.exceptionOrNull()
                Log.e("AldionRepository", ">>> [Step 3] Firestore Customer Sync FAILED! Message: ${syncErr?.message}", syncErr)
                return Result.failure(syncErr ?: Exception("فشل حفظ المدين في الفايربيس"))
            }

            Log.d("AldionRepository", ">>> [Step 4] Firestore Customer Sync SUCCESS!")

            // If initial debt > 0, save Operation to Firestore as well
            if (initialOpToSave != null) {
                val opSyncResult = firebaseManager.saveOperationSuspend(initialOpToSave!!)
                if (opSyncResult.isFailure) {
                    val opErr = opSyncResult.exceptionOrNull()
                    Log.e("AldionRepository", ">>> [Step 5] Firestore Operation Sync FAILED! Message: ${opErr?.message}", opErr)
                    return Result.failure(opErr ?: Exception("فشل حفظ عملية الدين في الفايربيس"))
                }
                Log.d("AldionRepository", ">>> [Step 6] Firestore Operation Sync SUCCESS!")
            }

            // Mark customer as synced in Room DB
            customerDao.updateCustomer(createdCustomer.copy(isSynced = true))

            Log.d("AldionRepository", ">>> [Step 7] All sync steps completed successfully for Customer ID: $customerId!")
            Result.success(customerId)
        } catch (e: Exception) {
            Log.e("AldionRepository", ">>> [Step Error] Exception in addCustomer: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun updateCustomer(customer: Customer): Result<Unit> {
        val trimmedName = customer.name.trim()
        Log.d("AldionRepository", ">>> [UpdateCustomer] Initiated for ID: ${customer.id}, Name: '$trimmedName'")

        if (trimmedName.isEmpty()) {
            return Result.failure(IllegalArgumentException("اسم المدين مطلوب"))
        }

        val existing = customerDao.getCustomerByName(trimmedName)
        if (existing != null && existing.id != customer.id) {
            return Result.failure(IllegalStateException("اسم المدين هذا مستخدم بالفعل"))
        }

        return try {
            val updated = customer.copy(
                name = trimmedName,
                phone = customer.phone?.trim()?.ifEmpty { null },
                isSynced = false
            )
            customerDao.updateCustomer(updated)

            val syncResult = firebaseManager.saveCustomerSuspend(updated)
            if (syncResult.isFailure) {
                val syncErr = syncResult.exceptionOrNull()
                Log.e("AldionRepository", ">>> [UpdateCustomer] Firestore Sync FAILED! Message: ${syncErr?.message}", syncErr)
                return Result.failure(syncErr ?: Exception("فشل تعديل البيانات في الفايربيس"))
            }

            customerDao.updateCustomer(updated.copy(isSynced = true))
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("AldionRepository", ">>> [UpdateCustomer] Exception: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun deleteCustomer(customer: Customer): Result<Unit> {
        return try {
            customerDao.deleteCustomer(customer)
            firebaseManager.deleteCustomer(customer.id)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addOperation(
        customerId: Long,
        type: OperationType,
        amount: Long,
        note: String
    ): Result<AddOperationResult> {
        if (amount <= 0) {
            return Result.failure(IllegalArgumentException("يجب أن يكون المبلغ أكبر من صفر"))
        }

        return try {
            val result = database.withTransaction {
                val customer = customerDao.getCustomerById(customerId)
                    ?: throw IllegalStateException("المدين غير موجود")

                val newDebtAmount = when (type) {
                    OperationType.DEBT -> customer.debtAmount + amount
                    OperationType.PAYMENT -> {
                        if (amount > customer.debtAmount) {
                            throw IllegalArgumentException("المبلغ المراد تسديده أكبر من الدين الحالي (${customer.debtAmount.formatCurrency()})")
                        }
                        customer.debtAmount - amount
                    }
                }

                val updatedCustomer = customer.copy(debtAmount = newDebtAmount, isSynced = false)
                customerDao.updateCustomer(updatedCustomer)

                val operation = Operation(
                    customerId = customerId,
                    type = type,
                    amount = amount,
                    note = note.trim(),
                    dateTime = System.currentTimeMillis(),
                    isSynced = false
                )
                val opId = operationDao.insertOperation(operation)

                val isZeroDebt = (type == OperationType.PAYMENT && newDebtAmount == 0L)
                AddOperationResult(
                    operationId = opId,
                    isZeroDebtReached = isZeroDebt,
                    updatedCustomer = updatedCustomer,
                    operation = operation.copy(id = opId)
                )
            }

            val custSyncResult = firebaseManager.saveCustomerSuspend(result.updatedCustomer)
            if (custSyncResult.isFailure) {
                val syncErr = custSyncResult.exceptionOrNull()
                Log.e("AldionRepository", ">>> [addOperation] Firestore Customer Sync FAILED: ${syncErr?.message}", syncErr)
                return Result.failure(syncErr ?: Exception("فشل حفظ تكييف الحساب في الفايربيس"))
            }

            val opSyncResult = firebaseManager.saveOperationSuspend(result.operation)
            if (opSyncResult.isFailure) {
                val syncErr = opSyncResult.exceptionOrNull()
                Log.e("AldionRepository", ">>> [addOperation] Firestore Operation Sync FAILED: ${syncErr?.message}", syncErr)
                return Result.failure(syncErr ?: Exception("فشل حفظ العملية في الفايربيس"))
            }

            customerDao.updateCustomer(result.updatedCustomer.copy(isSynced = true))
            operationDao.updateSyncStatus(result.operation.id, true)

            Result.success(result)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteOperation(opWithCustomer: OperationWithCustomer): Result<Unit> {
        val op = opWithCustomer.operation
        val customerId = op.customerId

        return try {
            val updatedCust = database.withTransaction {
                val customer = customerDao.getCustomerById(customerId)
                var updated: Customer? = null
                if (customer != null) {
                    val recalculatedDebt = when (op.type) {
                        OperationType.DEBT -> {
                            (customer.debtAmount - op.amount).coerceAtLeast(0L)
                        }
                        OperationType.PAYMENT -> {
                            customer.debtAmount + op.amount
                        }
                    }
                    updated = customer.copy(debtAmount = recalculatedDebt, isSynced = false)
                    customerDao.updateCustomer(updated)
                }
                operationDao.deleteOperation(op)
                updated
            }

            firebaseManager.deleteOperation(op.id, updatedCust)
            syncWithCloud()

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
